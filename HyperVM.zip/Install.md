thanks for downloading hypervm all tutorial in my github 
https://github.com/hypernestz/hypervm
and for support you can into my discord 
https://discord.gg/K2ntAwCsdJ   



help for Variables
in cpu if you want same cpu in host chagne to "host" or "max"
for help name of cpu you can get intro here 
https://github.com/hypernestz/hypervm/blob/main/cpu-model.txt

for example :
 x86 EPYC-Milan            (alias configured by machine type)
 x86 EPYC-Milan-v1         AMD EPYC-Milan Processor
 x86 core2duo              (alias configured by machine type)
x86 core2duo-v1           Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz
x86 coreduo               (alias configured by machine type)
x86 coreduo-v1            Genuine Intel(R) CPU           T2600  @ 2.16GHz
x86 kvm32                 (alias configured by machine type)
x86 kvm32-v1              Common 32-bit KVM processor
x86 kvm64                 (alias configured by machine type)
x86 kvm64-v1              Common KVM processor
x86 n270                  (alias configured by machine type)
x86 n270-v1               Intel(R) Atom(TM) CPU N270   @ 1.60GHz
x86 pentium               (alias configured by machine type)
x86 pentium-v1            
x86 pentium2              (alias configured by machine type)
x86 pentium2-v1           
x86 pentium3              (alias configured by machine type)
x86 pentium3-v1           
x86 phenom                (alias configured by machine type)
x86 phenom-v1             AMD Phenom(tm) 9550 Quad-Core Processor
x86 qemu32                (alias configured by machine type)
x86 qemu32-v1             QEMU Virtual CPU version 2.5+
x86 qemu64                (alias configured by machine type)
x86 qemu64-v1             QEMU Virtual CPU version 2.5+
x86 base                  base CPU model type with no features enabled
x86 host                  processor with all supported host features 
x86 max                   Enables all features supported by the accelerator in the current host


